﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Morze
{
    internal class Morzek
    {
        public string betu;
        public string kod;

        public Morzek(string betu, string kod ) 
        {
            this.betu = betu;
            this.kod = kod;
        }
    }
}
